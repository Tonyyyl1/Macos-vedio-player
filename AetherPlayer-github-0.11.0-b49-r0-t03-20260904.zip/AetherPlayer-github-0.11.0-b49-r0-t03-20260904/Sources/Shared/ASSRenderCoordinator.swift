import Foundation
import Combine
import CryptoKit
import OSLog
import AetherEngine
import SwiftAssRenderer

/// Drives swift-ass-renderer from AetherEngine's data surface for
/// styled ASS/SSA subtitle tracks (AetherEngine#30 host contract):
///
///   raw paced event cues (`preserveASSMarkup`) + `TrackInfo.assHeader`
///   -> `ASSScriptBuilder` -> batched `reloadTrack(content:)`
///   `engine.clock.$sourceTime` -> `setTimeOffset`
///   `engine.fontAttachments` -> font directory -> `FontConfig`
///
/// One instance per session, owned by `PlayerViewModel`; inactive until an ASS/SSA track selected.
@MainActor
final class ASSRenderCoordinator {
    nonisolated private static let fontCacheLogger = Logger(subsystem: "de.superuser404.AetherPlayer", category: "ASSFonts")

    /// Non-nil exactly while an ASS track is active AND the renderer initialized; else the
    /// overlay falls back to the text path.
    private(set) var renderer: AssSubtitlesRenderer?

    /// Fires immediately BEFORE every `reloadTrack` so the overlay can suppress the renderer's
    /// transient re-parse nil deterministically (a pure time-based window loses the race when
    /// re-parse + font matching runs long and the sub blinks mid-line).
    let reloadSignal = PassthroughSubject<Void, Never>()

    private let player: AetherEngine
    private var builder: ASSScriptBuilder?
    private var cancellables = Set<AnyCancellable>()
    private var lastReloadAt = Date.distantPast
    private var pendingEvents = false
    /// Earliest start among events added since the last reload; drives the imminent-flush bypass.
    private var earliestPendingStart = Double.infinity
    /// Last clock-sink offset (source-PTS seconds), compared against `earliestPendingStart`.
    private var lastOffset: Double = 0
    /// Batch window before reparsing the whole script. Per-cue reload (1-2/s) is pointless churn;
    /// in steady-state streaming the side demuxer runs ~90 s ahead so new events are far off.
    private let reloadInterval: TimeInterval = 5
    /// Imminent-flush bypass: after a seek/mid-dialogue activation the catch-up burst delivers
    /// events within seconds of the playhead; holding them the full window drops a running
    /// dialogue's continuation lines (field repro: subs "ending too early" right after scrubs).
    /// A pending event starting inside this lead flushes immediately.
    private let imminentLeadSeconds: Double = 10
    /// Spacing even for imminent flushes so the post-seek catch-up burst (~1-2 s) coalesces into
    /// a few reloads instead of one libass parse per cue.
    private let minImminentSpacing: TimeInterval = 0.25

    init(player: AetherEngine) {
        self.player = player
    }

    /// Fired when the renderer becomes available asynchronously (first activation with unwritten
    /// fonts) or is torn down; PlayerViewModel mirrors it onto its observable surface.
    var onRendererChanged: ((AssSubtitlesRenderer?) -> Void)?
    /// Guards async font-write completion against a deactivate/re-activate during the writes.
    private var activationGeneration = 0

    /// Activate for the selected embedded track (`header` = track's `assHeader`). Bails (renderer
    /// stays nil, caller keeps the text path) when the header is missing or setup fails.
    /// Fonts are written off-main (anime MKVs embed dozens of 5-20 MB CJK faces); when all files
    /// already exist the renderer installs synchronously so `activate(...); renderer` still works.
    func activate(header: String?, itemID: String) {
        deactivate()
        guard let header, !header.isEmpty else { return }
        activationGeneration += 1
        let generation = activationGeneration
        let fontsDir = Self.fontsDirectory(itemID: itemID)
        let fonts = player.fontAttachments
        if Self.allFontsPresent(fonts, in: fontsDir) {
            installRenderer(fontsDir: fontsDir)
        } else {
            Task.detached(priority: .userInitiated) { [weak self] in
                Self.writeFontAttachments(fonts, to: fontsDir)
                // Hop back via an isolated method rather than `MainActor.run { self... }`: capturing
                // self inside a MainActor.run closure from a detached task trips "sending self risks
                // data races" on some toolchains (Xcode 26.3). An await on a MainActor-isolated method
                // of the (implicitly Sendable) @MainActor class is the concurrency-safe equivalent.
                await self?.installRendererIfCurrent(generation: generation, fontsDir: fontsDir)
            }
        }
        let builder = ASSScriptBuilder(header: header)
        self.builder = builder

        // Cue sink: accumulate raw event lines, reload batched. Post-seek re-emits (cue array
        // resets) are absorbed by the builder's ReadOrder dedupe.
        player.$subtitleCues
            .receive(on: DispatchQueue.main)
            .sink { [weak self] cues in self?.consume(cues: cues) }
            .store(in: &cancellables)

        // Clock sink: cue times and sourceTime share the source-PTS coordinate (no conversion).
        // Doubles as trailing-batch flush, since the cue sink only runs on cue-array emissions
        // and a batch landing in the window with no later emission (EOF tail) would never flush.
        player.clock.$sourceTime
            .receive(on: DispatchQueue.main)
            .sink { [weak self] t in
                guard let self else { return }
                self.lastOffset = t
                self.renderer?.setTimeOffset(t)
                self.flushPendingEventsIfDue()
            }
            .store(in: &cancellables)
    }

    func deactivate() {
        activationGeneration += 1
        cancellables.removeAll()
        renderer?.freeTrack()
        renderer = nil
        builder = nil
        pendingEvents = false
        earliestPendingStart = .infinity
        lastReloadAt = .distantPast
    }

    private func installRenderer(fontsDir: URL) {
        let config = FontConfig(fontsPath: fontsDir, fontProvider: .coreText)
        let renderer = AssSubtitlesRenderer(fontConfig: config)
        self.renderer = renderer
        onRendererChanged?(renderer)
        // Surface events that arrived in the builder while fonts were being written.
        flushPendingEventsIfDue()
    }

    /// Main-actor continuation of `activate` after off-main font writes; installs the renderer
    /// unless a newer activation (or a deactivate) has superseded this one.
    private func installRendererIfCurrent(generation: Int, fontsDir: URL) {
        guard activationGeneration == generation else { return }
        installRenderer(fontsDir: fontsDir)
    }

    private func consume(cues: [SubtitleCue]) {
        guard let builder else { return }
        var addedAny = false
        for cue in cues {
            guard case .text(let raw) = cue.body else { continue }
            if builder.add(rawEventText: raw, start: cue.startTime, end: cue.endTime) {
                addedAny = true
                earliestPendingStart = min(earliestPendingStart, cue.startTime)
            }
        }
        if addedAny { pendingEvents = true }
        flushPendingEventsIfDue()
    }

    /// Reload the track when events are waiting and either the batch window elapsed or a pending
    /// event is imminent (within `imminentLeadSeconds`). Called from the cue sink and clock sink.
    /// `lastReloadAt` starts `.distantPast` so the first batch always passes the interval check.
    private func flushPendingEventsIfDue() {
        guard pendingEvents, let builder, let renderer else { return }
        let now = Date()
        let elapsed = now.timeIntervalSince(lastReloadAt)
        let imminent = earliestPendingStart <= lastOffset + imminentLeadSeconds
        let due = imminent ? elapsed >= minImminentSpacing : elapsed >= reloadInterval
        guard due else { return }
        lastReloadAt = now
        pendingEvents = false
        earliestPendingStart = .infinity
        reloadSignal.send()
        renderer.reloadTrack(content: builder.script())
    }

    // MARK: - Fonts

    private static func fontsDirectory(itemID: String) -> URL {
        // The old basename-only directory collided for unrelated files such as
        // /Anime/A/episode.mkv and /Anime/B/episode.mkv. A digest also makes a
        // remote URL safe to use as a directory component without sanitization.
        let dirName = Self.digest(itemID.isEmpty ? "item" : itemID)
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("ass-fonts", isDirectory: true)
            .appendingPathComponent(dirName, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        } catch {
            Self.fontCacheLogger.error("Could not create ASS font cache directory: \(error.localizedDescription, privacy: .public)")
        }
        return base
    }

    private nonisolated static func allFontsPresent(_ fonts: [FontAttachment], in dir: URL) -> Bool {
        fonts.allSatisfy { font in
            guard let name = fontCacheFilename(font) else { return true }
            return FileManager.default.fileExists(atPath: dir.appendingPathComponent(name).path)
        }
    }

    private nonisolated static func writeFontAttachments(_ fonts: [FontAttachment], to dir: URL) {
        for font in fonts {
            guard let name = fontCacheFilename(font) else { continue }
            let url = dir.appendingPathComponent(name)
            if !FileManager.default.fileExists(atPath: url.path) {
                do {
                    // Atomic so a crash mid-write can't leave a truncated font the exists-check
                    // above would then treat as complete forever.
                    try font.data.write(to: url, options: .atomic)
                } catch {
                    fontCacheLogger.error("Could not write cached ASS font: \(error.localizedDescription, privacy: .public)")
                }
            }
        }
    }

    private nonisolated static func fontCacheFilename(_ font: FontAttachment) -> String? {
        let safeName = (font.filename as NSString).lastPathComponent
        guard !safeName.isEmpty, safeName != ".", safeName != ".." else { return nil }
        // Same filename can carry a different embedded font in another track.
        return "\(digest(font.data))--\(safeName)"
    }

    private nonisolated static func digest(_ value: String) -> String {
        digest(Data(value.utf8))
    }

    private nonisolated static func digest(_ value: Data) -> String {
        SHA256.hash(data: value).map { String(format: "%02x", $0) }.joined()
    }
}
